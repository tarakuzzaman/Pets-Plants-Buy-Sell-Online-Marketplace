<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\User;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin.dashboard');
    }

    public function manage2()
    {
        $users = User::all();

        return view('admin.dashboard', ['userInfo' => $users]);
    }
}





