<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Categories;

class CategoryController extends Controller
{
    public function index()
    {
        return view('admin.category.categoryEntry');
    }

    public function manage()
    {
        $category = categories::all();

        return view('admin.category.categoryManage', ['allData' => $category]);
    }

    public function save(Request $request)
    {
        $categoryEntry = new Categories();

        $categoryEntry->categoryName = $request->category_name;
        $categoryEntry->shortDescription = $request->shortDescription;
        $categoryEntry->publicationStatus = $request->publicationStatus;

        $categoryEntry->save();

        return redirect('/admin/category/entry');
    }

    public function edit($id)
    {
        $categoryEdit = Categories::where('id', $id)->first();

        return view('admin.category.categoryEdit', ['categoryEdit' => $categoryEdit]);
    }

    public function update(Request $request)
    {
        //dd($request->all());

        $categpryUpdate = Categories::find($request->categoryId);
        $categpryUpdate->categoryName = $request->category_name;
        $categpryUpdate->shortDescription = $request->shortDescription;
        $categpryUpdate->publicationStatus = $request->publicationStatus;
        $categpryUpdate->save();

        return redirect('/admin/category/manage');
    }

    public function delete($id)
    {
       $categoryDelete = Categories::find($id);
        $categoryDelete->delete();

        return redirect('admin/category/manage');

    }
}







