<?php

namespace App\Http\Controllers\Admin;

use App\Products;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function manage()
    {
        $products = DB::table('products')
            ->join('categories', 'categories.id', '=', 'categoryId')
            ->select('products.*', 'categories.categoryName as catName')
            ->paginate(10);

        return view('admin.product.productManage', ['productDetails' => $products]);
    }

    public function view($id)
    {
        $productById = DB::table('products')
            ->join('categories', 'categories.id', '=', 'categoryId')
            ->select('products.*', 'categories.categoryName as catName')
            ->where('products.id', $id)
            ->first();
        return view('admin.product.productView',['product' => $productById]);
    }

    public function delete($id)
    {
        $productDelete = Products::find($id);
        $productDelete->delete();

        return redirect('/admin/product/manage');
    }


}

