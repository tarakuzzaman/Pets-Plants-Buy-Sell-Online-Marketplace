<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Products;

class ProductController extends Controller
{
    public function manage()
    {

        $products = DB::table('products')
            ->join('categories', 'categories.id', '=', 'categoryId')
            ->select('products.*', 'categories.categoryName as catName')
            ->paginate(8);

        return view('frontEnd.home.homeContent', ['productDetails' => $products]);

    }

    public function view($id)
    {
        $productById = DB::table('products')
            ->join('categories', 'categories.id', '=', 'categoryId')
            ->select('products.*', 'categories.categoryName as catName')
            ->where('products.id', $id)
            ->first();
        return view('singleProduct', ['product' => $productById]);
    }


    public function singleView($id)
    {
        $productById = DB::table('products')
            ->join('categories', 'categories.id', '=', 'categoryId')
            ->select('products.*', 'categories.categoryName as catName')
            ->where('products.id', $id)
            ->first();
        return view('productsView', ['product' => $productById]);
    }





//    public function search(Request $request)
//    {
//
//        if ($request->search) {
//            $searchs = DB::table('products')
//                        ->where('name','like','%'.$request->search.'%')
//                        ->get();
//            if($searchs){
//                foreach($searchs as $key=>$search){
//                    <div class="typeimage">
//                      <img src="{{asset($search->picture)}}" width="60" alt="Image">
//                      <div class="shadow ">
//                          <div class="shadowtext">
//                            <h3>{{$search->name}}</h3>
//                            <h2>{{$search->price}}</h2>
//                            <p><a href="{{url('/product/view/'.$search->id)}}" target="__blank" style="clear: both;">View More</a></p>
//                          </div>
//                      </div>
//                    </div>
//                }
//            }
//        }
//
//
////        $search = $request->get('search');
////        $post = DB::table('products')->where('name', 'like', '%' . $search . '%')->paginate(5);
////        return view('frontEnd.home.homeContent', ['post' => $post]);
//    }

}















