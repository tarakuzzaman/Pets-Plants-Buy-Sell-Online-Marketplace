<?php

namespace App\Http\Controllers\User;

use App\Categories;
use App\Products;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function index()
    {
        $categories = categories::where('publicationStatus', 1)->get();
        return view('frontEnd.users.addProduct', ['publicationStatus' => $categories]);
    }

    public function save(Request $request)
    {
        //dd($request->all());

        $obj = new Products();
        $obj->name = $request->category_name;
        $obj->categoryId = $request->categoryId;
        $obj->quantity = $request->quantity;
        $obj->price = $request->price;
        $obj->place = $request->place;
        $obj->mobile = $request->mobile;
        $obj->picture = 'picture';
        $obj->picture2 = 'picture';
        $obj->picture3 = 'picture';

        $obj->save();
        $lastId = $obj->id;

        $picInfo = $request->file('pic');
        $picInfo2 = $request->file('pic2');
        $picInfo3 = $request->file('pic3');

        $picName = $lastId . $picInfo->getClientOriginalName();
        $picName2 = $lastId . $picInfo2->getClientOriginalName();
        $picName3 = $lastId . $picInfo3->getClientOriginalName();

        $folder = "productImage/";

        $picInfo->move($folder, $picName);
        $picInfo2->move($folder, $picName2);
        $picInfo3->move($folder, $picName3);

        $picUrl = $folder . $picName;
        $picUrl2 = $folder . $picName2;
        $picUrl3 = $folder . $picName3;

        $productPic = Products::find($lastId);
        $productPic2 = Products::find($lastId);
        $productPic3 = Products::find($lastId);

        $productPic->picture = $picUrl;
        $productPic2->picture2 = $picUrl2;
        $productPic3->picture3 = $picUrl3;

        $productPic->save();
        $productPic2->save();
        $productPic3->save();

        return redirect('/user/users/profile');

    }

    public function view()
    {
        return view('frontEnd.users.singleProduct');
    }

//    public function manage()
//    {
//        $products = DB::table('products')
//            ->join('categories','categories.id','=','categoryId')
//            ->select('products.*','categories.categoryName as catName')
//            ->get();
//        return view('frontEnd.home.homeContent',['product'=>$products]);
//    }
}







