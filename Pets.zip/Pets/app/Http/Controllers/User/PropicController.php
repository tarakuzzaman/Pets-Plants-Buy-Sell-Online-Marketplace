<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PropicController extends Controller
{
    public function save(Request $request)
    {
        dd($request);
    }
}
