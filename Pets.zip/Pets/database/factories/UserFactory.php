<?php

use App\User;
use Illuminate\Support\Str;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(Products::class, function (Faker $faker) {
    return [
//        'name' => $faker->word,
//        'categoryId' => $faker->string,
//        'quantity' => $faker->numberBetween($min = 1, $max = 10000),
//        'price' => $faker->numberBetween($min = 50, $max = 2147483647),
//        'place' => $faker->text,
//        'mobile' => $faker->text,
//        'pic' => $faker->image($dir = productImage, $width = 60, $height = 40, $category = null, $fullPath = true, $randomize = true, $word = null),
//        'pic2' => $faker->image($dir = productImage, $width = 60, $height = 40, $category = null, $fullPath = true, $randomize = true, $word = null),
//        'pic3' => $faker->image($dir = productImage, $width = 60, $height = 40, $category = null, $fullPath = true, $randomize = true, $word = null),

    ];
});
