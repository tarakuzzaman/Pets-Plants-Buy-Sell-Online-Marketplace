-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2019 at 11:29 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pets&plants`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `categoryName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shortDescription` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `publicationStatus` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categoryName`, `shortDescription`, `publicationStatus`, `created_at`, `updated_at`) VALUES
(6, 'Bird', 'Birds, also known as Aves, are a group of endothermic vertebrates, characterised by feathers, toothless beaked jaws, the laying of hard-shelled eggs, a high metabolic rate, a four-chambered heart, and a strong yet lightweight skeleton. Wikipedia', 1, '2019-04-25 10:47:53', '2019-04-25 10:49:04'),
(7, 'Plants', 'Plants are mainly multicellular, predominantly photosynthetic eukaryotes of the kingdom Plantae. Historically, plants were treated as one of two kingdoms including all living things that were not animals, and all algae and fungi were treated as plants.', 1, '2019-04-25 10:48:53', '2019-05-01 15:14:12'),
(8, 'Pets', 'Pets Description Pets Description Pets Description Pets Description Pets Description Pets Description', 1, '2019-04-27 12:10:06', '2019-04-27 12:10:18');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_04_17_053149_create_roles_table', 1),
(4, '2019_04_24_124955_create_categories_table', 2),
(6, '2019_04_26_112647_create_products_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryId` tinyint(4) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double(10,2) NOT NULL,
  `place` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture2` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture3` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `categoryId`, `quantity`, `price`, `place`, `mobile`, `picture`, `picture2`, `picture3`, `created_at`, `updated_at`) VALUES
(16, 'Bazrika', 6, 4, 800.00, '98/3,kalabagan,dhanmondi,dhaka', '01234567890', 'productImage/16download.jpg', 'productImage/16images (1).jpg', 'productImage/16images.jpg', '2019-04-27 11:21:08', '2019-04-27 11:21:08'),
(17, 'Persian Cat', 8, 5, 75000.00, 'Mogbazar', '01234896578', 'productImage/17download (1).jpg', 'productImage/17images (2).jpg', 'productImage/17images (3).jpg', '2019-04-27 12:12:36', '2019-04-27 12:12:36'),
(19, 'Belly', 7, 2, 100.00, '98/3,kalabagan,dhanmondi,dhaka', '01700000000', 'productImage/19images (4).jpg', 'productImage/19450px-Jasminum_sambac_\'Grand_Duke_of_Tuscany\'.jpg', 'productImage/19FB_IMG_1516355549207.jpg', '2019-04-28 05:28:16', '2019-04-28 05:28:16'),
(20, 'Alovera', 7, 5, 200.00, '10/6/A, Sobhanbag, Dhanmondi, Dhaka', '01749208654', 'productImage/20download.jpg', 'productImage/20download (3).jpg', 'productImage/20download (2).jpg', '2019-04-29 13:43:00', '2019-04-29 13:43:00'),
(22, 'Zebra Finch', 6, 2, 800.00, '98/3,kalabagan,dhanmondi,dhaka', '01796987468', 'productImage/22finches1.jpg', 'productImage/22images (5).jpg', 'productImage/22images (6).jpg', '2019-04-29 13:48:40', '2019-04-29 13:48:40'),
(23, 'Cockatiel', 6, 1, 1500.00, 'mirpur 1', '01987564258', 'productImage/23download (6).jpg', 'productImage/23download (5).jpg', 'productImage/23download (4).jpg', '2019-04-30 04:53:14', '2019-04-30 04:53:15'),
(24, 'Zebra Finch', 6, 12, 4800.00, '48/6 Shukrabad, Dhanmondi, Dhaka', '01521475869', 'productImage/24images (7).jpg', 'productImage/24download (7).jpg', 'productImage/24GroupOfZebraFinchesOnBranch.jpg.653x0_q80_crop-smart.jpg', '2019-04-30 12:26:36', '2019-04-30 12:26:36'),
(26, 'Gouldian Finch', 6, 3, 14000.00, '98/3, Lake circus, Kalabagan, Dhanmondi, Dhaka', '01586987458', 'productImage/26images (8).jpg', 'productImage/26images (9).jpg', 'productImage/26pictures-of-colorful-birds-12-most-beautiful-colorful-birds-of-the-world.jpg', '2019-04-30 12:31:00', '2019-04-30 12:31:00'),
(27, 'পরতুলিকা', 7, 2, 200.00, 'dhanmondi 32', '01234896578', 'productImage/2758671948_2433743776911494_5603501616134094848_n.jpg', 'productImage/2758766149_2433743813578157_956096502189522944_n.jpg', 'productImage/2758671948_2433743776911494_5603501616134094848_n.jpg', '2019-04-30 14:42:20', '2019-04-30 14:42:21'),
(28, 'marantas', 7, 6, 600.00, '10/6/A, Sobhanbag, Dhanmondi, Dhaka', '01234896578', 'productImage/2858383925_1246314425530492_3602267553092599808_n.jpg', 'productImage/2858852856_1246315572197044_2167671759522758656_n.jpg', 'productImage/2858378796_1246314288863839_5340221413674450944_n.jpg', '2019-04-30 14:45:15', '2019-04-30 14:45:15'),
(29, 'Money Plant', 7, 5, 400.00, '98/3,kalabagan,dhanmondi,dhaka', '01234896578', 'productImage/2958381376_10215118812784686_737938362853228544_n.jpg', 'productImage/2958381376_10215118812784686_737938362853228544_n (1).jpg', 'productImage/2958583764_10215118813024692_3634392881969496064_n.jpg', '2019-04-30 14:46:58', '2019-04-30 14:46:59'),
(30, 'Meghalaya Dog', 8, 1, 8000.00, 'Mohammadpur', '01568987568', 'productImage/3041WpgXUoUqL._SX331_BO1,204,203,200_.jpg', 'productImage/3051cc84hBwRL._SX331_BO1,204,203,200_.jpg', 'productImage/30download (1).jpg', '2019-05-01 01:28:38', '2019-05-01 01:28:38'),
(31, 'গোলাপ', 7, 2, 800.00, 'dhanmondi 32', '01757485869', 'productImage/31exquisite-xxl-long-stemmed-roses-movie-star-rose-super-flowers-collection.jpg', 'productImage/3141W1-m6w2+L.jpg', 'productImage/31exquisite-xxl-long-stemmed-roses-movie-star-rose-super-flowers-collection.jpg', '2019-05-01 12:53:49', '2019-05-01 12:53:49'),
(33, 'Ejipsian Dumur', 7, 2, 500.00, '105,2, nidmohol, dhanmondi, dhaka', '01741258585', 'productImage/33download (9).jpg', 'productImage/33download.jpg', 'productImage/33download (9).jpg', '2019-05-01 13:12:48', '2019-05-01 13:12:48'),
(34, 'Bazrika', 6, 2, 500.00, '48/3,shukrabad, dhanmondi, dhaka', '01789568425', 'productImage/34images (1).jpg', 'productImage/34images.jpg', 'productImage/34images (1).jpg', '2019-05-01 13:49:34', '2019-05-01 13:49:34'),
(35, 'German Shepherd', 8, 1, 8000.00, '98/3, Kalabagan, Lake circus, Dhanmondi, Dhaka', '01897582536', 'productImage/35German-Shepherd-puppies.jpg', 'productImage/35German-Shepherd-puppy-1024x1024.jpg', 'productImage/351.jpg', '2019-05-01 14:05:16', '2019-05-01 14:05:16'),
(36, 'জবা', 7, 5, 50.00, '105,2, nidmohol, dhanmondi, dhaka', '01757485869', 'productImage/3658442235_1244125552416046_3313195170077343744_n.jpg', 'productImage/3657882477_1244125589082709_6491402687727271936_n.jpg', 'productImage/3658711561_1244125662416035_3702527671922589696_n.jpg', '2019-05-01 15:15:40', '2019-05-01 15:15:40'),
(37, 'nil kontho', 7, 2, 320.00, 'nakhalpara', '01741475868', 'productImage/3757433669_1242632065898728_2235688948976320512_n.jpg', 'productImage/3757454639_1242213439273924_65335386104135680_n.jpg', 'productImage/3757433669_1242632065898728_2235688948976320512_n.jpg', '2019-05-01 15:17:11', '2019-05-01 15:17:11'),
(38, 'সূর্যমুখী', 7, 9, 890.00, 'green road', '0154875695', 'productImage/3853367895_1206511252844143_237969084010987520_n.jpg', 'productImage/3853367895_1206511252844143_237969084010987520_n.jpg', 'productImage/3853367895_1206511252844143_237969084010987520_n.jpg', '2019-05-01 15:19:29', '2019-05-01 15:19:29'),
(39, 'Thai peyara', 7, 4, 2600.00, 'panthapath', '01852459698', 'productImage/3955455445_1222874104541191_5930758135311499264_n.jpg', 'productImage/3954523656_1222874087874526_178387102952587264_n.jpg', 'productImage/3955455445_1222874104541191_5930758135311499264_n.jpg', '2019-05-01 15:20:36', '2019-05-01 15:20:36'),
(40, 'rabit', 8, 3, 3250.00, 'farmget', '01854695212', 'productImage/40images (10).jpg', 'productImage/40images (11).jpg', 'productImage/401 (1).jpg', '2019-05-01 15:23:14', '2019-05-01 15:23:14'),
(41, 'Rabbit', 8, 1, 1400.00, 'dhanmondi 8/A', '0321548502', 'productImage/41images (13).jpg', 'productImage/41images (12).jpg', 'productImage/41images (14).jpg', '2019-05-01 15:24:44', '2019-05-01 15:24:45');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin', NULL, NULL),
(2, 'Users', 'users', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '2',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `email_verified_at`, `password`, `image`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Admin', 'hridoyadmin@gmail.com', NULL, '$2y$10$lHmE5AfaaKrZ5s6KTVeMoOV/w9FpUMcroi2oUdlo9pqjAAbygaaAm', 'default.png', NULL, NULL, NULL),
(2, 2, 'hamid', 'hamid@gmail.com', NULL, '$2y$10$VNPZGcZP4hkolGTf2.hFhuRlkWCjn6kSThhvzKTWeJAxm7/4p9SiS', 'default.png', NULL, NULL, NULL),
(4, 2, 'ratul', 'hassan@gmail.com', NULL, '$2y$10$DGKYgf3VL8Br4aypEOYAgOGofwzGTcVwAwUanu0Scn7mxfXlklIS.', 'default.png', NULL, '2019-04-17 11:41:39', '2019-04-17 11:41:39'),
(6, 2, 'rayhan', 'rayhan.kabir120@gmail.com', NULL, '$2y$10$gDlycHH3rKIdIuuyNLFfueuNc2O53XTURfqA68t2j6bQpWF4djt.C', 'default.png', NULL, '2019-04-21 01:53:54', '2019-04-21 01:53:54'),
(7, 2, 'ratul', 'fardin@gmail.com', NULL, '$2y$10$aQFYdVtx/nBu5TVaVLsz6.qJKStzBLkFcg8kEA2FEY6uzcaueQ4u.', 'default.png', NULL, '2019-04-27 12:08:24', '2019-04-27 12:08:24'),
(8, 2, 'S H K', 'shk@gmail.com', NULL, '$2y$10$kW.Wk5Fhs9HjUShwA0.ACuenYNEgvJmlJEUPOEe9xOLl7.TNTN4Ti', 'default.png', NULL, '2019-04-29 10:13:43', '2019-04-29 10:13:43'),
(9, 2, 'Fahim', 'fahimrazvi9@gmail.com', NULL, '$2y$10$O8n89bOd/tc0mbwkINsEmeejwUmAk1Y99YunaE5oZGlOw/0.1K8v2', 'default.png', NULL, '2019-05-01 01:25:35', '2019-05-01 01:25:35'),
(10, 2, 'original', 'khan@gmail.com', NULL, '$2y$10$5Nya8uooozStijKl20qqROsNQK3kcV50cH0Ds270P3a48GLtGVV0K', 'default.png', NULL, '2019-05-01 03:47:35', '2019-05-01 03:47:35'),
(11, 2, 'Akash', 'akashkhan@gmail.com', NULL, '$2y$10$paPaoYWVq4BhTdAsWi3f3ezKct6Sbt4dC5FZdEa3YWRbgIehUS8q.', 'default.png', NULL, '2019-05-01 13:48:07', '2019-05-01 13:48:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
