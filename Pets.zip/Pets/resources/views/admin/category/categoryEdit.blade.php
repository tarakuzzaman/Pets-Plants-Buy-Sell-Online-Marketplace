@extends('admin.master')

@section('title_area')
    Admin area Category Edit
@endsection

@section('css_js')
    <link href="{{ asset('admin') }}/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="{{ asset('admin') }}/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{ asset('admin') }}/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="{{ asset('admin') }}/vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="{{ asset('admin') }}/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
@endsection

@section('content_heading')
    <marquee><b>Category Edit</b></marquee>
@endsection

@section('contents')

        {!! Form::open(['url'=>'admin/category/edit','name'=>'editForm','method'=>'post','role'=>'form']) !!}
        <div class="form-group col-lg-8" >
            <label>Category Name</label>
            <input type="text" name="category_name"  value="{{$categoryEdit->categoryName}}" class="form-control">
        </div>
        <div class="form-group col-lg-8">
            <label>Description</label>
            <textarea name="shortDescription"   class="form-control" placeholder="Enter Short Description">{{$categoryEdit->shortDescription}}</textarea>
        </div>
        <div class="form-group col-lg-8">
            <label>Publication Status</label>
            <select name="publicationStatus" {{$categoryEdit->publicationStatus}} class="form-control">
                <option value="0">Unpublished</option>
                <option value="1">Published</option>
            </select>
        </div>
        <div class="form-group col-lg-8">
            <button type="submit" value="submit" class="btn btn-primary ">Submit Button</button>
        </div>

        <input type="hidden" name="categoryId" value="{{$categoryEdit->id}}">

    {!! Form::close() !!}

        <script type="text/javascript">
            document.forms['editForm'].elements['publicationStatus'].value='{{$categoryEdit->publicationStatus}}'
        </script>

@endsection