@extends('admin.master')

@section('title_area')
    Admin area Category Entry
@endsection

@section('css_js')
    <link href="{{ asset('admin') }}/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="{{ asset('admin') }}/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{ asset('admin') }}/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="{{ asset('admin') }}/vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="{{ asset('admin') }}/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="{{asset('admin')}}/css/style.css">




@endsection


@section('dashboard_header')
    <marquee><b>Category Entry</b></marquee>
@endsection


@section('contents')
    {!! Form::open(['url'=>'admin/category/save','id'=>'save','method'=>'post','role'=>'form']) !!}
    <div class="form-group col-lg-8" >
        <label>Category Name</label>
        <input type="text" name="category_name" id="name" class="form-control" id="category_name">
        <small id="error_categoryName" class="form-text text-danger msg_error">Category name is required</small>
    </div>
    <div class="form-group col-lg-8">
        <label>Description</label>
        <textarea name="shortDescription" id="shortDescription"  class="form-control" placeholder="Enter Short Description"></textarea>
        <small id="error_description" class="form-text text-danger msg_error">Description is required</small>
    </div>
    <div class="form-group col-lg-8">
        <label>Publication Status</label>
        <select name="publicationStatus" id="publicationStatus" class="form-control">
            <option value="0">Unpublished</option>
            <option value="1">Published</option>
        </select>
    </div>
    <div class="form-group col-lg-8">
        <button type="submit" value="submit" class="btn btn-primary ">Submit Button</button>
    </div>
    {!! Form::close() !!}


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>



    <script>
        $(document).ready(function(){
            $("#save").validate({
                rules: {

                    category_name: {
                        required: true,
                    },

                    shortDescription: {
                        required: true,
                    },

                    publicationStatus: {
                        required: true,

                    },


                    agree: "required"
                },
                messages: {

                    category_name: "Please fill up the field",

                    shortDescription: "Please fill up the field",

                    publicationStatus: "Please select an option",

                    agree: "Please accept our policy"
                }
            });
        });
    </script>


@endsection
