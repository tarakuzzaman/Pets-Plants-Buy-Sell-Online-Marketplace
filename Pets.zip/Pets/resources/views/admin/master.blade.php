<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>@yield('title_area')</title>

    <!-- Bootstrap Core CSS -->
    @yield('css_js')

    <style>
        label.error{
            color: red
        }
    </style>

</head>

<body>

<div id="soft-all-wrapper">

    <!-- Navigation -->
   @include('admin.inc.navigate')

    <div id="page-wrapper">
        @yield('dashboard_header')

        @yield('content_heading')
        <!-- /.row -->
         @yield('view_details')
        <!-- /.row -->
        @yield('contents')

        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="{{ asset('admin') }}/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="{{ asset('admin') }}/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="{{ asset('admin') }}/vendor/metisMenu/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="{{ asset('admin') }}/vendor/raphael/raphael.min.js"></script>
<script src="{{ asset('admin') }}/vendor/morrisjs/morris.min.js"></script>
<script src="{{ asset('admin') }}/data/morris-data.js"></script>

<!-- Custom Theme JavaScript -->
<script src="{{ asset('admin') }}/dist/js/sb-admin-2.js"></script>

</body>

</html>
