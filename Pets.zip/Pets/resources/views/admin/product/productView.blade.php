@extends('admin.master')

@section('title_area')
    Admin area Product Manage
@endsection

@section('css_js')
    <link href="{{ asset('admin') }}/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="{{ asset('admin') }}/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{ asset('admin') }}/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="{{ asset('admin') }}/vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="{{ asset('admin') }}/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
@endsection

@section('content_heading')
    <marquee><b>Product Manage</b></marquee>
@endsection

@section('contents')
    <div class="row">
        <div class="left" style="float: left;">
            <img src="{{asset($product->picture)}}" alt="Image", width="500" height="400"><hr><br>
            <img src="{{asset($product->picture2)}}" alt="Image", width="250" height="200">
            <img src="{{asset($product->picture3)}}" alt="Image", width="250" height="200">
        </div>
        <div class="right" style="float:right;margin-right: 200px; background-color: transparent;">
            <div class="panel-body">

                <strong> Name : </strong>{{$product->name}}<br><hr>
                <strong> Category Name : </strong>{{$product->catName}}<br><hr>
                <strong> Quantity : </strong>{{$product->quantity}}<br><hr>
                <strong> Price : </strong> ৳ {{$product->price}}<br><hr>
                <strong> Place : </strong>{{$product->place}}<br><hr>
                <strong> Phone No : </strong><strong>{{$product->mobile}}</strong><br><br>

            </div>
        </div>
    </div>
@endsection










