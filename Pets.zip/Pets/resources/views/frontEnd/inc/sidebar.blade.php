<div class="col-md-2 col-sm-2 container-fluid">
    <div class="sidnave">
        <ul>
            <li><a href="{{url('/')}}">Home</a></li>
            <li><a href="{{url('/about')}}">About</a></li>
            <li><a href="#">Settings</a></li>

            <li><a href="#">Blog</a></li>
            <li><a href="#">Support center</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>
    </div>
</div>