@foreach($productDetails2 as $products2)
    {{$products2->price}}
@endforeach