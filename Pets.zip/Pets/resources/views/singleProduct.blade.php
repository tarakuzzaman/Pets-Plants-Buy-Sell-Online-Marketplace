@extends('frontEnd.master2')

@section('title_area')
    Pets & Plants
    @endsection

    @section('css_js')
            <!-- Bootstrap -->
    <link href="{{asset('frontEnd')}}/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{asset('frontEnd')}}/css/style.css" rel="stylesheet">

    <!-- owl-carousel -->
    <link rel="stylesheet" href="{{asset('frontEnd')}}/css/owl.carousel.min.css">
    <link href="{{asset('frontEnd')}}/css/owl.theme.default.min.css" rel="stylesheet">

    <!-- fontasome -->
    <link rel="stylesheet" href="{{asset('frontEnd/font-awesome/css')}}/font-awesome.css"/>
    <link rel="stylesheet" href="{{asset('frontEnd/font-awesome/css')}}/font-awesome.min.css"/>
@endsection

@section('main_content')
    <div class="row">
        <div class="left" style="float: left;">
            <img src="{{asset($product->picture)}}" alt="Image", width="500" height="400"><hr><br>
            <img src="{{asset($product->picture2)}}" alt="Image", width="250" height="200">
            <img src="{{asset($product->picture3)}}" alt="Image", width="250" height="200">
        </div>
        <div class="right" style="float:right;margin-right: 200px; background-color: transparent;">
            <div class="panel-body">

                 <strong> Name : </strong>{{$product->name}}<br><hr>
                 <strong> Category Name : </strong>{{$product->catName}}<br><hr>
                 <strong> Quantity : </strong>{{$product->quantity}}<br><hr>
                 <strong> Price : </strong> ৳ {{$product->price}}<br><hr>
                 <strong> Place : </strong>{{$product->place}}<br><hr>
                 <strong> Phone No : </strong><strong>{{$product->mobile}}</strong><br><br>

            </div>
        </div>
    </div>
@endsection













