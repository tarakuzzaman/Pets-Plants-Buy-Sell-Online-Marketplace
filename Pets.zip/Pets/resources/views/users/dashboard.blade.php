<html>
    <head>

    </head>
    <body>
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
        <div class="container">
            <a class="navbar-brand" href="{{ url('/') }}">
                {{ config('', 'Pets & Plants') }}
            </a>
        </div>
    </nav>
    </body>
</html>


