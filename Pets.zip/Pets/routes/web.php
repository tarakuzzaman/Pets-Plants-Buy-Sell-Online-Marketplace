<?php

use App\Products;
use Illuminate\Support\Facades\Input;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::any('/search',function(){
        $q = Input::get ( 'q' );
        $product = Products::where('name','LIKE','%'.$q.'%')->get();

                return view('frontEnd.home.homeContent2',['products'=>$product]);
       });




Route::get('/', 'ProductController@manage');
Route::get('/product/view/{id}','ProductController@view');
Route::get('/product/viewSearch/{id}','ProductController@singleView');

Route::get('/about','AboutController@index');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::group(['as'=>'admin.','prefix' => 'admin', 'namespace' => 'admin', 'middleware' => ['auth', 'admin']],

    function () {
        Route::get('/dashboard','AdminController@index')->name('dashboard');
        Route::get('/category/entry','CategoryController@index')->middleware('AuthenticateMiddleWare');
        Route::get('/category/manage','CategoryController@manage')->middleware('AuthenticateMiddleWare');
        Route::post('/category/save','CategoryController@save')->middleware('AuthenticateMiddleWare');
        Route::get('/category/edit/{id}','CategoryController@edit')->middleware('AuthenticateMiddleWare');
        Route::post('/category/edit/','CategoryController@update')->middleware('AuthenticateMiddleWare');
        Route::get('/category/delete/{id}','CategoryController@delete')->middleware('AuthenticateMiddleWare');
        Route::get('/product/manage/','ProductController@manage')->middleware('AuthenticateMiddleWare');
        Route::get('/product/view/{id}','ProductController@view')->middleware('AuthenticateMiddleWare');
        Route::get('/product/delete/{id}','ProductController@delete')->middleware('AuthenticateMiddleWare');
        Route::get('/user/manage','UserController@manage')->middleware('AuthenticateMiddleWare');
        Route::get('/user/delete/{id}','UserController@delete')->middleware('AuthenticateMiddleWare');
        Route::get('/dashboard','AdminController@manage2')->middleware('AuthenticateMiddleWare');


    }

);
Route::group(['as'=>'user.','prefix' => 'user', 'namespace' => 'user', 'middleware' => ['auth', 'user']],

    function () {
        Route::get('/dashboard','UserController@index')->name('dashboard');
        Route::get('/users/profile','ProfileController@index')->middleware('AuthenticateMiddleWare');
        Route::get('/users/addProduct','ProductController@index')->middleware('AuthenticateMiddleWare');
        Route::post('/users/addProduct','ProductController@save')->middleware('AuthenticateMiddleWare');
        Route::get('/users/singleProduct','ProductController@view')->middleware('AuthenticateMiddleWare');
        //Route::post('/users/proPic','UserController@save')->middleware('AuthenticateMiddleWare');


    }

);


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
