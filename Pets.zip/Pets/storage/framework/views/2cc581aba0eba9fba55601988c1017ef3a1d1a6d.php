<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $__env->yieldContent('title_area'); ?></title>

    <!-- Bootstrap Core CSS -->
    <?php echo $__env->yieldContent('css_js'); ?>

    <style>
        label.error{
            color: red
        }
    </style>

</head>

<body>

<div id="soft-all-wrapper">

    <!-- Navigation -->
   <?php echo $__env->make('admin.inc.navigate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="page-wrapper">
        <?php echo $__env->yieldContent('dashboard_header'); ?>

        <?php echo $__env->yieldContent('content_heading'); ?>
        <!-- /.row -->
         <?php echo $__env->yieldContent('view_details'); ?>
        <!-- /.row -->
        <?php echo $__env->yieldContent('contents'); ?>

        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="<?php echo e(asset('admin')); ?>/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('admin')); ?>/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo e(asset('admin')); ?>/vendor/metisMenu/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="<?php echo e(asset('admin')); ?>/vendor/raphael/raphael.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/vendor/morrisjs/morris.min.js"></script>
<script src="<?php echo e(asset('admin')); ?>/data/morris-data.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo e(asset('admin')); ?>/dist/js/sb-admin-2.js"></script>

</body>

</html>
