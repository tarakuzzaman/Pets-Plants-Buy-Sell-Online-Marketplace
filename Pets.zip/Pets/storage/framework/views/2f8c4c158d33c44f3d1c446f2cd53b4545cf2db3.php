<div class="col-md-2 col-sm-2 container-fluid">
    <div class="sidnave">
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
            <li><a href="#">Settings</a></li>

            <li><a href="#">Blog</a></li>
            <li><a href="#">Support center</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>
    </div>
</div>