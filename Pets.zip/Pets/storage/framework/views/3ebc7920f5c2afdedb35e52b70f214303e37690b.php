<?php $__env->startSection('title_area'); ?>
    Admin area Product Manage
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_js'); ?>
    <link href="<?php echo e(asset('admin')); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo e(asset('admin')); ?>/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('admin')); ?>/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="<?php echo e(asset('admin')); ?>/vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('admin')); ?>/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_heading'); ?>
    <marquee><b>Product Manage</b></marquee>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div class="row">
        <div class="left" style="float: left;">
            <img src="<?php echo e(asset($product->picture)); ?>" alt="Image", width="500" height="400"><hr><br>
            <img src="<?php echo e(asset($product->picture2)); ?>" alt="Image", width="250" height="200">
            <img src="<?php echo e(asset($product->picture3)); ?>" alt="Image", width="250" height="200">
        </div>
        <div class="right" style="float:right;margin-right: 200px; background-color: transparent;">
            <div class="panel-body">

                <strong> Name : </strong><?php echo e($product->name); ?><br><hr>
                <strong> Category Name : </strong><?php echo e($product->catName); ?><br><hr>
                <strong> Quantity : </strong><?php echo e($product->quantity); ?><br><hr>
                <strong> Price : </strong> ৳ <?php echo e($product->price); ?><br><hr>
                <strong> Place : </strong><?php echo e($product->place); ?><br><hr>
                <strong> Phone No : </strong><strong><?php echo e($product->mobile); ?></strong><br><br>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>