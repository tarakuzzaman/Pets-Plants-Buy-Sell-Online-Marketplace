    <?php $__env->startSection('title_area'); ?>
        Pets & Plants
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css_js'); ?>
        <!-- Bootstrap -->
        <link href="<?php echo e(asset('frontEnd')); ?>/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo e(asset('frontEnd')); ?>/css/style.css" rel="stylesheet">

        <!-- owl-carousel -->
        <link rel="stylesheet" href="<?php echo e(asset('frontEnd')); ?>/css/owl.carousel.min.css">
        <link href="<?php echo e(asset('frontEnd')); ?>/css/owl.theme.default.min.css" rel="stylesheet">

        <!-- fontasome -->
        <link rel="stylesheet" href="<?php echo e(asset('frontEnd/font-awesome/css')); ?>/font-awesome.css"/>
        <link rel="stylesheet" href="<?php echo e(asset('frontEnd/font-awesome/css')); ?>/font-awesome.min.css"/>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('main_content'); ?>
       <div class="col-md-8 col-sm-6 col-xs-12">
           <?php echo Form::open(['url'=>'user/users/addProduct','id'=>'addProduct','method'=>'post','enctype'=>'multipart/form-data','role'=>'form']); ?>

               <div class="form-group col-lg-8" >
                   <label> Name</label>
                   <input type="text" placeholder="What do you want to sell" name="category_name" class="form-control" id="name">
               </div>
               <div class="form-group col-lg-8" >
                   <label>Select Category</label>
                   <select name="categoryId" class="form-control" id="category">
                       <option>Choose Category</option>
                       <?php $__currentLoopData = $publicationStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($category->id); ?>"><?php echo e($category->categoryName); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
               </div>
               <div class="form-group col-lg-8" >
                   <label>Quantity</label>
                   <input type="text" placeholder="Ex: 2" name="quantity" class="form-control" id="quantity">
               </div>
               <div class="form-group col-lg-8" >
                   <label>Price</label>
                   <input type="text" placeholder="Ex: 800.00" name="price" class="form-control"  id="price">
               </div>
               <div class="form-group col-lg-8" >
                   <label>Place</label>
                   <input type="text" placeholder="Ex: 105/2,Dhanmondi6/A,Dhaka" name="place" class="form-control"  id="place">
               </div>
               <div class="form-group col-lg-8" >
                   <label>Phone No</label>
                   <input type="text" placeholder="01700000000" name="mobile" class="form-control" id="mobile">
               </div>
               <div class="form-group col-lg-8" >
                   <label>Picture 1</label>
                   <input type="file" name="pic"  id="pic">
               </div>
               <div class="form-group col-lg-8" >
                   <label>Picture 2</label>
                   <input type="file" name="pic2"  id="pic2">
               </div>
               <div class="form-group col-lg-8" >
                   <label>Picture 3</label>
                   <input type="file" name="pic3"  id="pic3">
               </div>

               <div class="form-group col-lg-8">
                   <button type="submit" value="submit" class="btn btn-primary ">Submit </button>
               </div>
           <?php echo Form::close(); ?>


           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
           <script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>



           <script>
               $(document).ready(function(){
                   $("#addProduct").validate({
                       rules: {

                           category_name: {
                               required: true,
                           },
                           categoryId: {
                               required: true,
                           },
                           quantity: {
                               required: true,
                           },
                           price: {
                               required: true,
                           },
                           place: {
                               required: true,
                           },

                           mobile: {
                               required: true,
                           },

                           pic: {
                               required: true,

                           },
                           pic2: {
                               required: true,

                           },
                           pic3: {
                               required: true,

                           },


                           agree: "required"
                       },
                       messages: {

                           category_name: "Please fill up the field",

                           categoryId: "Please fill up the field",

                           quantity: "Please fill up the field",

                           price: "Please fill up the field",

                           place: "Please fill up the field",

                           mobile: "Please fill up the field",

                           pic: "Please select an image",

                           pic2: "Please select an image",

                           pic3: "Please fill up the field",

                           agree: "Please select an image"
                       }
                   });
               });
           </script>

       </div>
    <?php $__env->stopSection(); ?>







<?php echo $__env->make('frontEnd.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>