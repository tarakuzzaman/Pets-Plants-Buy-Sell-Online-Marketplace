<nav class="navbar navbar-default">
    <div class="container-fluid" style="background-color: #2B96CC;">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>" style="color: #fff;">PETS AND PLANTS</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

            <form class="navbar-form navbar-left" name="q" action="<?php echo e(url('/search')); ?>">
                <div class="input-group">
                    <input type="search"  name="q" class="form-control"
                           placeholder="Search">

                    <div class="input-group-btn">
                        <button class="btn btn-default" type="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </div>
                </div>
            </form>

            <script>
                
                

                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                

                
                




            </script>

            <ul class="nav navbar-nav navbar-right">

                <li class="dropdown">
                    <?php if(Auth::check()): ?>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: #fff;">
                        <i class="fa fa-user fa-fw"></i><?php echo e(Auth::user()->name); ?><i class="fa fa-caret-down"></i>
                    </a>


                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="<?php echo e(url('/user/users/profile')); ?>"><i class="fa fa-user fa-fw"></i> User
                                Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>

                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <i class="fa fa-sign-out fa-fw"></i><?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                        <?php else: ?>
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="<?php echo e(route('login')); ?>" style="color: #fff;">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>" style="color: #fff;">Register</a></li>
                        </ul>
                        <?php endif; ?>
                    <!-- /.dropdown-user -->
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>