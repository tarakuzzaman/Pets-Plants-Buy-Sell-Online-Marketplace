<?php $__currentLoopData = $productDetails2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($products2->price); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>