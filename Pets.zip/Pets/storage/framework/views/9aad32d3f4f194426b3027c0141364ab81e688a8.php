<?php $__env->startSection('title_area'); ?>
    Pets & Plants
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_js'); ?>
    <!-- Bootstrap -->
    <link href="<?php echo e(asset('frontEnd')); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontEnd')); ?>/css/style.css" rel="stylesheet">

    <!-- owl-carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd')); ?>/css/owl.carousel.min.css">
    <link href="<?php echo e(asset('frontEnd')); ?>/css/owl.theme.default.min.css" rel="stylesheet">

    <!-- fontasome -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/font-awesome/css')); ?>/font-awesome.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/font-awesome/css')); ?>/font-awesome.min.css"/>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('main_content'); ?>


    <div class="col-md-10 generalData">


        <?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="typeimage">
                <img src="<?php echo e(asset($singleProduct->picture)); ?>" width="60" alt="Image">
                <div class="shadow ">
                    <div class="shadowtext">
                        <h3><?php echo e($singleProduct->name); ?></h3>
                        <h2> ৳ <?php echo e($singleProduct->price); ?></h2>
                        <p><a href="<?php echo e(url('/product/view/'.$singleProduct->id)); ?>" target="__blank" style="clear: both;">View More</a></p>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>



    <div class="col-md-10 ajaxdata" id="success">

    </div>


<?php echo e($productDetails->links()); ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer_js'); ?>


    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
    <script src="<?php echo e(asset('frontEnd')); ?>/js/jquery.counterup.min.js"></script>



    <script>
        jQuery(document).ready(function($) {
            $('.counter').counterUp({
                delay: 5,
                time: 1000
            });
        });
    </script>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo e(asset('frontEnd')); ?>/js/bootstrap.min.js"></script>
    <!-- owl cuarasol -->
    <script src="<?php echo e(asset('frontEnd')); ?>/js/jQuery-3.2.1.min.js"></script>
    <script src="<?php echo e(asset('frontEnd')); ?>/js/owl.carousel.min.js"></script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>