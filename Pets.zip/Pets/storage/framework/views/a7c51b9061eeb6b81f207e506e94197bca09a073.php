<?php $__env->startSection('title_area'); ?>
    Pets & Plants
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css_js'); ?>
            <!-- Bootstrap -->
    <link href="<?php echo e(asset('frontEnd')); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontEnd')); ?>/css/style.css" rel="stylesheet">

    <!-- owl-carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd')); ?>/css/owl.carousel.min.css">
    <link href="<?php echo e(asset('frontEnd')); ?>/css/owl.theme.default.min.css" rel="stylesheet">

    <!-- fontasome -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/font-awesome/css')); ?>/font-awesome.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/font-awesome/css')); ?>/font-awesome.min.css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="row">
        <div class="left" style="float: left;">
            <img src="<?php echo e(asset($product->picture)); ?>" alt="Image", width="500" height="400"><hr><br>
            <img src="<?php echo e(asset($product->picture2)); ?>" alt="Image", width="250" height="200">
            <img src="<?php echo e(asset($product->picture3)); ?>" alt="Image", width="250" height="200">
        </div>
        <div class="right" style="float:right;margin-right: 200px; background-color: transparent;">
            <div class="panel-body">

                 <strong> Name : </strong><?php echo e($product->name); ?><br><hr>
                 <strong> Category Name : </strong><?php echo e($product->catName); ?><br><hr>
                 <strong> Quantity : </strong><?php echo e($product->quantity); ?><br><hr>
                 <strong> Price : </strong> ৳ <?php echo e($product->price); ?><br><hr>
                 <strong> Place : </strong><?php echo e($product->place); ?><br><hr>
                 <strong> Phone No : </strong><strong><?php echo e($product->mobile); ?></strong><br><br>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>














<?php echo $__env->make('frontEnd.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>