    <?php $__env->startSection('title_area'); ?>
    Pets & Plants
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('css_js'); ?>
            <!-- Bootstrap -->
    <link href="<?php echo e(asset('frontEnd')); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontEnd')); ?>/css/style.css" rel="stylesheet">

    <!-- owl-carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd')); ?>/css/owl.carousel.min.css">
    <link href="<?php echo e(asset('frontEnd')); ?>/css/owl.theme.default.min.css" rel="stylesheet">

    <!-- fontasome -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/font-awesome/css')); ?>/font-awesome.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/font-awesome/css')); ?>/font-awesome.min.css"/>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('main_content'); ?>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <div class="container" >
        <h1 class="page-header">Profile</h1>
        <div class="row">
            <!-- left column -->

                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="text-center">
                        <img src="<?php echo e(asset('frontEnd')); ?>/img/123.png"  width="200px" alt="Image" style="border-radius: 50%;">
                    </div>
                </div>

            <!-- edit form column -->
            <div class="col-md-4 col-sm-6 col-xs-12 new-post">
                
                    
                    
                    
                

                <form class="form-horizontal" role="form">


                    <div>
                        <a href="<?php echo e(url('/user/users/addProduct')); ?>" style="text-decoration: none;
                                                                            margin: 80px auto 20px;
                                                                            display: block;
                                                                            font-size: 15px;
                                                                             background-color: #f1f1f1;
                                                                             text-align: center;
                                                                             width: 150px;
                                                                             height: 150px;

                        "><h1 style="">+</h1>Create New Post </a>
                    </div>

                    <div class="ja-issa-tai">
                        <a href="<?php echo e(url('/')); ?> "style="text-decoration: none;
                                                        margin: 80px auto 20px;
                                                        display: block;
                                                        font-size: 15px;
                                                        background-color: #f1f1f1;
                                                        text-align: center;
                                                        width: 150px;
                                                        height: 150px;
                        "><h3 style="margin-top: 50px">View All Post</h3></a>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer_js'); ?>


    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
    <script src="<?php echo e(asset('frontEnd')); ?>/js/jquery.counterup.min.js"></script>
    <script>
        jQuery(document).ready(function($) {
            $('.counter').counterUp({
                delay: 5,
                time: 1000
            });
        });
    </script>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo e(asset('frontEnd')); ?>/js/bootstrap.min.js"></script>


    <!-- owl cuarasol -->
    <script src="<?php echo e(asset('frontEnd')); ?>/js/jQuery-3.2.1.min.js"></script>
    <script src="<?php echo e(asset('frontEnd')); ?>/js/owl.carousel.min.js"></script>
    <script>

        $(document).ready(function(){

            $(".tomar-slider").owlCarousel({
                items 		: 4,
                autoplay 	: true,
                loop		: false,
                nav 		: false,
                navText     : ['<i class="fa fa-angle-left"></i>' , '<i class="fa fa-angle-right"></i>'],
                dotData 	: true,
                dotsEach 	: true,
                smartSpeed 	: 2000,
                autoplayTimeout : 5000,
                animateIn		: 'fadeIn',
                animateOut		: 'fadeOut',
                dotsContainer  	: true,
                margin 			: 0
            });

        });

    </script>




    <script>
        $(document) .ready(function(){
            $('ul.nav li.dropdown').hover(function(){
                $('.dropdown-menu', this).fadeIn();

            }, function(){
                $('.dropdown-menu', this).fadeOut('fast');

            });//hover



        });


    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>